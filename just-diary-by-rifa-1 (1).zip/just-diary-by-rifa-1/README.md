# Just Diary By Rifa 1

A Pen created on CodePen.

Original URL: [https://codepen.io/Mosaddik-Hosain-the-sasster/pen/ByaGabW](https://codepen.io/Mosaddik-Hosain-the-sasster/pen/ByaGabW).

